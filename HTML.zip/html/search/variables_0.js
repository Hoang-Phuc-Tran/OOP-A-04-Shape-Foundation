var searchData=
[
  ['colour_0',['colour',['../class_shape.html#a525db72bc0e96e0daa2c1bd0ce8cb076',1,'Shape']]],
  ['colour_5fvalid_1',['COLOUR_VALID',['../class_shape.html#a35f38477388c7f8195e64a5412f13458',1,'Shape']]]
];
