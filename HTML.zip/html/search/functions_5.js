var searchData=
[
  ['setcolour_0',['SetColour',['../class_shape.html#a2f53969417c2a8d7310ea0c3e39bb0c1',1,'Shape']]],
  ['setname_1',['SetName',['../class_shape.html#aaf4cec46e6d8dec15de25be6c1d8fb7d',1,'Shape']]],
  ['setradius_2',['SetRadius',['../class_circle.html#a09f07ad86e16507b6db8bee35aa67962',1,'Circle']]],
  ['setsidelength_3',['SetSideLength',['../class_square.html#a2529ce0bf833b155cef0712fa9fe988a',1,'Square']]],
  ['shape_4',['Shape',['../class_shape.html#afe4be928fe35fecb1fa0a9579571df96',1,'Shape::Shape(string newName, string newColour)'],['../class_shape.html#a2c81e227edd2803a084c65c75e4ffd5b',1,'Shape::Shape(void)']]],
  ['show_5',['Show',['../class_circle.html#a9ade44170d48efc91d3c35e8be4e4b5a',1,'Circle::Show()'],['../class_shape.html#ab7020f0c5fdeacd75cce08a55e7b2329',1,'Shape::Show()'],['../class_square.html#a2a7e3a73cfbe9045d8a27dd8f738fda9',1,'Square::Show(void)']]],
  ['square_6',['Square',['../class_square.html#ab99fbb5ea8ba88349120e2f4f9a18b8a',1,'Square::Square(string newColour, double newSideLength)'],['../class_square.html#a7411e99cc5900fedb7d2f8e3eb74540a',1,'Square::Square(void)']]]
];
