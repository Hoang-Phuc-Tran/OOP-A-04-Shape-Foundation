var annotated_dup =
[
    [ "Circle", "class_circle.html", "class_circle" ],
    [ "Shape", "class_shape.html", "class_shape" ],
    [ "Square", "class_square.html", "class_square" ]
];