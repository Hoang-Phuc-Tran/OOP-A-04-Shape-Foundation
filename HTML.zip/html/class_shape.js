var class_shape =
[
    [ "Shape", "class_shape.html#afe4be928fe35fecb1fa0a9579571df96", null ],
    [ "Shape", "class_shape.html#a2c81e227edd2803a084c65c75e4ffd5b", null ],
    [ "~Shape", "class_shape.html#acff7ec5acd1acf7b45b1c8df29dd9d21", null ],
    [ "Area", "class_shape.html#a0fdf099ed5eefbc508a4660df0f690a0", null ],
    [ "GetColour", "class_shape.html#abb2339563a60f8c94e72f3fed923c875", null ],
    [ "GetName", "class_shape.html#a84850221524c39fc99d701d326edd830", null ],
    [ "OverallDimension", "class_shape.html#a75a0cb162699095d35fc86414f2d84fd", null ],
    [ "Perimeter", "class_shape.html#a18c4ee2257909bf4f84ea4e4b09d575e", null ],
    [ "SetColour", "class_shape.html#a2f53969417c2a8d7310ea0c3e39bb0c1", null ],
    [ "SetName", "class_shape.html#aaf4cec46e6d8dec15de25be6c1d8fb7d", null ],
    [ "Show", "class_shape.html#ab7020f0c5fdeacd75cce08a55e7b2329", null ],
    [ "validateInput", "class_shape.html#a1128a29e2d93e5935de2878e011a360e", null ],
    [ "colour", "class_shape.html#a525db72bc0e96e0daa2c1bd0ce8cb076", null ],
    [ "COLOUR_VALID", "class_shape.html#a35f38477388c7f8195e64a5412f13458", null ],
    [ "MAX_LENGTH_COLOUR", "class_shape.html#aa6ed206be951ba876bdc1ad12504d35d", null ],
    [ "MAX_LENGTH_NAME", "class_shape.html#a8dc597e71dcfeea1be97393459c98bec", null ],
    [ "name", "class_shape.html#afef5e9426226fd7af49fe48ec16b97f3", null ],
    [ "NAME_VALID", "class_shape.html#a5867cd7856d68a91e371486e619315fe", null ],
    [ "NOT_VALID", "class_shape.html#a661bb87065eea86546e0cb63dcf002db", null ],
    [ "PI", "class_shape.html#a5c6ca3abd97839380e72189d69d06bd7", null ]
];